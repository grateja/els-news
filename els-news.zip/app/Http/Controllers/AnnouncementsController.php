<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Announcement;
use Carbon\Carbon;

class AnnouncementsController extends Controller
{
    public function getAnnouncement() {
        $announcement = Announcement::orderBy('id', 'desc')
            ->whereDate('date', Carbon::now())
            ->first();

        return response()->json([
            'announcement' => $announcement
        ], 200);
    }
}
