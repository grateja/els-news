$(document).ready(function() {
    const template = $('#newsTemplate').html();
    const news = $('#newsContent');
    var page = 1;

    function getInitialNews() {
        $.get({
            url: `/api/news/get-initial-news`,
            success(res) {
                let articles = res.news.articles;
                let $html = '';

                for (let index = 0; index < articles.length; index++) {
                    const article = articles[index];
                    $html += toHtmlArticle(article);
                }

                $('#newsContent').html($html);

                setTimeout(pushNews, 5000);
            }
        });
    }

    function toHtmlArticle(article) {
        return template.replace(/{{title}}/, article.title)
        .replace(/{{description}}/, article.description)
        .replace(/{{urlToImage}}/, article.urlToImage);
    }

    function pushNews() {
        if(page >= 20) {
            page = 1;
        }
        $.get({
            url: '/api/news/get-news',
            data: {
                page: page++
            },
            success(res) {
                pushArticle(toHtmlArticle(res.article));
                setTimeout(pushNews, 10000);
            },
            error(err) {
                console.log('Failed to load news resource', err);
                setTimeout(pushNews, 60000);
            }
        })
    }

    function pushArticle(articleHtml) {
        $(news).children().first().hide(1500, function() {
            $(this).remove();
            $(news).append(articleHtml);
        });
    }

    getInitialNews();
});
