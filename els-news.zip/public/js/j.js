$('document').ready(function() {

    const current = {};
    const sliderTemplate = $('#sliderTemplate').html();
    const slideTemplate = $('#slideTemplate').html();

    getKeys();

    function getKeys() {
        $.get({
            url: `/api/check/all`,
            success(res) {

                if(current.board != res.board) {
                    // board changed
                    console.log('board changed', res.board);
                    getBoard();
                }

                if(current.announcement != res.announcement) {
                    // announcement changed
                    console.log('announcement changed', res.announcement);
                    getAnnouncement();
                }

                current.announcement = res.announcement;
                current.board = res.board;

                setTimeout(getKeys, 10000);
            }
        });
    }

    function getBoard() {
        $.get({
            url: `/api/boards/today`,
            success(res) {
                if(res.event.event_type_id == 1) {
                    let slides = res.event.slides;

                    let slider = sliderTemplate.replace(/{{slides}}/, toHtmlSlider(slides));

                    $('#boardContent').html(slider);

                    $('.slider_circle_10').EasySlides({
                        autoplay: true,
                        'timeout': 8000,
                        // 'show': 5,
                        // 'vertical': false,
                        // 'reverse': false,
                        // 'touchevents': true,
                        // 'delayaftershow': 300,
                        // 'stepbystep': true,
                        // 'startslide': 0,
                        // 'loop': true,
                        // 'distancetochange': 15,
                        // 'beforeshow': function () {},
                        // 'aftershow': function () {},
                    })
                }
                // $('#boardContent').html(`<pre>${JSON.stringify(res.event)}</pre>`);
            }
        });
    }

    function toHtmlSlide(slide) {
        console.log('slide', slide)
        return slideTemplate.replace(/{{source}}/, slide.source);
    }

    function toHtmlSlider(slides) {
        console.log('slides', slides);
        let htmlSlide = '';
        for (let index = 0; index < slides.length; index++) {
            const slide = slides[index];
            htmlSlide += toHtmlSlide(slide);
        }
        return htmlSlide;
    }

    function getAnnouncement() {
        $.get({
            url: `/api/announcements/get-announcement`,
            success(res) {
                $('#announcementContent').text(res.announcement.content);
            }
        })
    }

    setInterval(function() {
        let date = new Date();
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0'+minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
        $('#time').text(strTime);

        $('#date').text(date.toDateString());
    }, 1000);

});
