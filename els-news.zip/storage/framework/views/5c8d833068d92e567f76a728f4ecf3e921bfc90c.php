<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="events">
        <a href="/events/create">Create new event</a>
        <hr>
        <ul class="list-group">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <h4><a href="/boards/<?php echo e($event->eventType->name); ?>/<?php echo e($event->id); ?>/preview"><?php echo e($event->title); ?></a></h4>
                    <p><?php echo e($event->description); ?></p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>