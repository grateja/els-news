<?php $__env->startSection('content'); ?>

<div class="container">
    <a href="/manage/create">Create event</a>
    <hr>
    <?php echo e($events); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>