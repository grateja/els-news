<div class="card p-3 my-3">
    <h3><?php echo e($event->title); ?></h3>
    <p class="font-italic text-secondary"><?php echo e($event->description); ?></p>
</div>
