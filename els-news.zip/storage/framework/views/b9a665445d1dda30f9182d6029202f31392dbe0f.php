<?php echo e($event); ?>

