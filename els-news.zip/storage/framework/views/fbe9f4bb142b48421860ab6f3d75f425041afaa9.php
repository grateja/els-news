<?php $__env->startSection('content'); ?>

<div class="container">
    <h3>Create new event</h3>
    <hr>
    <?php if($event): ?>
        <div class="alert alert-info">
            Saved from drafts.
        </div>
    <?php endif; ?>
    <form action="<?php echo e($action); ?>" method="POST">
        <?php echo e(csrf_field()); ?>


        <div class="form-group">
            <label for="date">Date:</label>
            <input type="date" name="date" id="date" class="form-control" value="<?php echo e(old('date') ? old('date') : $event ? $event->date : ''); ?>">
            <span class="text-danger"><?php echo e($errors->first('date')); ?></span>
        </div>

        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title') ? old('title') : $event ? $event->title : ''); ?>">
            <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
        </div>

        <div class="form-group">
            <label for="description">Description:</label>
            <textarea name="description" id="description" rows="5" class="form-control"><?php echo e(old('description') ? old('description') : $event ? $event->description : ''); ?></textarea>
        </div>

        <h4>Event type</h4>
        <hr>

        <?php $__currentLoopData = $eventTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check-inline">
                <label for="evt<?php echo e($eventType->id); ?>">
                    <input type="radio" name="event_type_id" id="evt<?php echo e($eventType->id); ?>" value="<?php echo e($eventType->id); ?>" <?php echo e($event ? ($eventType->id == $event->event_type_id ? 'checked' : '') : $eventType->id == 1 ? 'checked' : ''); ?>> <?php echo e($eventType->name); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>

        <div class="form-group">
            <input type="submit" value="Next" class="btn btn-primary btn-lg">
        </div>

    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>