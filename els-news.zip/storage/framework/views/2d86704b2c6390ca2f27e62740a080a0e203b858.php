<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" data-interval="8000">
    <div class="carousel-inner">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($img->order == 1 ? 'active' : ''); ?>">
                <img class="d-block w-100" src="/<?php echo e($img->source); ?>" alt="Second slide">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
