<?php $__env->startSection('content'); ?>

<div class="container">
    <slide-show id="<?php echo e($event->id); ?>" />
    <!-- <div class="row">
        <div class="col-sm-12">
            <?php echo $__env->make('boards/_event-partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <ul class="list-group">
                <?php $__currentLoopData = $event->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <img src="/<?php echo e($image->source); ?>" alt="" class="w-100">
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="col-sm-9">
            include('boards/slides/_slideshow-partial', ['images' => $event->images])
            <slide-show/>
        </div>
    </div> -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>