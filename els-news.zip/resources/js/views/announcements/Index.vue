<template>
    <v-container>
        <h3>Announcements</h3>
    </v-container>
</template>
