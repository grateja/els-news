<template>
    <v-container>
        <h3>News</h3>
    </v-container>
</template>
