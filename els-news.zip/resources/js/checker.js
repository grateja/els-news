// import store from './store/index.js';
// function check() {
//     axios.get('/api/check/all').then((res, rej) => {
//         console.log('changed', res.data);
//         setTimeout(check, 5000);
//     });
// }
// check();
