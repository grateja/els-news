<template>
    <div>
        {{id}}
    </div>
</template>

<script>
export default {
    props: [
        'id'
    ],
    data() {
        return {

        }
    },
    methods: {

    }
}
</script>
