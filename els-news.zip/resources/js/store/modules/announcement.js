const state = {
    currentAnnouncement: null
};

const mutations = {
    setAnnouncement(state, announcement) {
        state.currentAnnouncement = announcement;
        console.log('announcement', announcement);
    }
};

const actions = {
    loadAnnouncement(context) {
        return axios.get('/api/announcements/get-announcement').then((res, rej) => {
            console.log(res.data)
            context.commit('setAnnouncement', res.data.announcement);
            return res;
        });
    }
};

const getters = {
    getAnnouncement(state) {
        return state.currentAnnouncement;
    }
};

export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters
}
