@extends('layouts.app')

@section('content')

<div class="container">
    {{$event}}
</div>

@endsection
