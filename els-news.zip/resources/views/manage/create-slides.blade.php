@extends('layouts.app')

@section('content')

<div class="container">
    @include('manage/_event-partial')
</div>

@endsection
