@extends('layouts.app')

@section('content')

<div class="container">
    <h3>Manage</h3>
    <div id="app">

    </div>
</div>

@endsection
