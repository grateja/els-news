@extends('layouts.app')

@section('content')

<div class="container">
    @include('boards/_event-partial')
</div>

@endsection
