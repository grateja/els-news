<div class="card p-3 my-3">
    <h3>{{$event->title}}</h3>
    <p class="font-italic text-secondary">{{$event->description}}</p>
</div>
